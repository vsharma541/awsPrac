import {hello} from "@api/lodash-util";
export const handler = (event) => {
    console.log(hello());
};
// handler();